#pragma once

#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Scheme {
private:
	vector<string> names;

public:
	
	Scheme(){};
	~Scheme(){};
	
	
};

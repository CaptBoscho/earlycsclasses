package client;

import javax.swing.JPanel;

public class ImageTab extends JPanel{
	
	BatchState bs;
	
	public ImageTab(BatchState batch)
	{
		bs = batch;
	}

}

package client;

import javax.swing.JFrame;

import servertester.controllers.Controller;

public class Main {

	public static void main(String[] args) {
		

		String hostname = args[0];
		String temp = args[1];
		int port = Integer.parseInt(temp);
		JFrame p = new LoginParentFrame(hostname, port);
		
		
		
		//p.setVisible(false);
		
	}

}

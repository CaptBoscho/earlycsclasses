package client;


public interface IControl {

	void initialize();
	
	void operationSelected();
	
	void executeOperation();
}


package client;

import javax.swing.JFrame;

public class LoginParentFrame extends JFrame{

	String hostname;
	int port;
	
	public LoginParentFrame(String h, int p)
	{
		hostname = h;
		port = p;
		new LoginFrame(this);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
}

package searchgui;

import javax.swing.JFrame;

import servertester.controllers.Controller;

public class Main {

	public static void main(String[] args) {
		
		JFrame p = new LoginParentFrame();
		
		
		
		//p.setVisible(false);
		
	}

}
